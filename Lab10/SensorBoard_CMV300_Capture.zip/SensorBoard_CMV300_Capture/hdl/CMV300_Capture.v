`timescale 1ns / 1ps
//============================================================================
// CMV300_Capture.v - the four-pixel packer. THIS IS THE MODULE YOU WRITE.
//
//   CMV300_CaptureCore.v has already done the hard parts: it samples D[9:0],
//   LVAL and DVAL on the FALLING edge of CLK_OUT in IOB flops, brings them
//   into this rising-edge domain, selects between the sensor and the test
//   pattern, counts rows and pixels, and tells you when a frame has ended.
//
//   What reaches you, all registered and in the CLK_OUT rising-edge domain:
//     pixel        the 10-bit pixel on this cycle
//     pixel_valid  high when `pixel` is real (LVAL and DVAL both high)
//     line_valid   the registered LVAL. LOW between rows.
//     stream_en    acquisition gate. Push nothing when it is low.
//     frame_end    one cycle, at the end of a frame
//
//   What you produce - the frozen contract, see INTERFACE.md:
//     pix_data[47:0]  FOUR pixels, 12-bit lanes, {px3, px2, px1, px0},
//                     the FIRST pixel of the group in [11:0]. A 10-bit
//                     parallel-mode pixel sits in the low bits of its lane.
//     pix_valid       one cycle, when an entry is complete
//     pix_eof         one cycle, the end-of-frame token
//
//   648 = 4 x 162, so a row never leaves a partial entry.
//
//   THE PITFALL: clear the packer while line_valid is LOW. Not on its rising
//   edge - on the test pattern LVAL and DVAL rise together, so a reset there
//   lands on the first pixel of the row and swallows it. The image then shears
//   by one more pixel on every row. tb_lab10 catches it; the image does not.
//
//   Check your work:  python build.py --sim
//============================================================================
module CMV300_Capture (
    input  wire        clk,            // CLK_OUT, rising edge
    input  wire [9:0]  pixel,
    input  wire        pixel_valid,
    input  wire        line_valid,
    input  wire        stream_en,
    input  wire        frame_end,
    output reg         pix_valid,
    output reg  [47:0] pix_data,
    output reg         pix_eof
);

    // Suggested state. Replace it if you prefer.
    // reg [1:0]  pk4     = 2'd0;      // pixels collected so far, 0..3
    // reg [35:0] pk4_buf = 36'd0;     // the first three, in 12-bit lanes

    initial begin pix_valid = 1'b0; pix_data = 48'd0; pix_eof = 1'b0; end

    always @(posedge clk) begin
        pix_valid <= 1'b0;             // one-cycle strobe: default it low

        // ------------------------------------------------------------------
        // YOUR CODE HERE
        //
        //   accumulate a pixel when pixel_valid && stream_en
        //   on the fourth, drive pix_data and raise pix_valid for one cycle
        //   clear the packer while line_valid is low
        //   raise pix_eof for one cycle on frame_end (gated by stream_en)
        // ------------------------------------------------------------------
    end

endmodule
